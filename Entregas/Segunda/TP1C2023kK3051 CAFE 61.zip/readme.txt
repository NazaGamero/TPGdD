Curso: K3051 / K3014
Numero de grupo: 61
Nicolas Penna, 1761936
Nazareno Gamero, 1765050
Carmen Villalta Cardenas, 1476520
Responsable de grupo: npenna@frba.utn.edu.ar